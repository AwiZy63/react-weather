import React, { Component } from "react";
import './scss/main.scss';
import axios from 'axios';

import Day2 from './components/Day2';
import Day3 from './components/Day3';
import Day4 from './components/Day4';
import Day5 from './components/Day5';

import GetPosition from './components/GetPosition'

export default class App extends Component {

  state = {
    data: {},
  }



  componentDidMount() {

    let latitude = 50.4291723;
    let longitude = 2.8319805;

    //console.log(latitude)
    //console.log(longitude)

    let WEATHER_API = `https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&units=metric&lang=fr&exclude=minutely,hourly,alerts&appid=37bddde895b74620b111148941cfe613`;

    axios.get(`${WEATHER_API}`)

      .then(res => {
        this.setState({
          data: res.data
        })
      })

    //console.log(this.state.data)

  }
  render() {

    const data = this.state.data;

    if (Object.keys(data).length !== 0) {

      const today = data.current;
      const todayWeekDay = new Date(today.dt * 1000).toLocaleString("fr-FR", { weekday: "long" });

/*      const daysJSX = data.daily.map(day => {
        const dayName = new Date(day.dt * 1000).toLocaleString("fr-FR", { weekday: "long" });
        const dayTemp = day.temp.day;
        const dayDesc = day.weather[0].description
//        return <p>{dayName}: test | {dayTemp} | {dayDesc}</p>
      })*/

      const icon_today = this.state.data.current.weather[0].icon;
      const img_today = `http://openweathermap.org/img/wn/${icon_today}@2x.png`

      // Checker que data est vide
      // S'il est pas vide, alors this.state.data.current... a une valeur
      return (

        <div className="App">
          <div className="mainbox">
            <div className="box_nextday today">
              <img src={img_today} alt="" />
              <div className="content">
                <p className="day_name">{todayWeekDay}</p>
                <h1>Ville de Lens</h1>
                <p className="day_infos">Temperature: {this.state.data.current.temp}°C</p>
                <p className="day_infos">{this.state.data.current.weather[0].description}</p>
              </div>
              {/* <p>Dernière actualisation : {lastRefresh}</p> */}
            </div>

            <div className="previsions">
              <div className="previsions_box">

                <Day2 />
                <Day3 />
                <Day4 />
                <Day5 />
                <GetPosition />

              </div>
            </div>
          </div>
        </div>
      );
    } else {
      // Sinon j'affiche un loading
      return (
        <p>Loading...</p>
      );
    }
  }
}
