import React, { Component } from 'react'
import axios from 'axios';

export default class GetPosition extends Component {
    state = {
        value: '',
        data: {}
    }

    componentDidMount() {


        let ville = "Paris";
          

        let LOCATION_API = `https://nominatim.openstreetmap.org/search/${ville}?format=json&limit=1`;

        axios.get(`${LOCATION_API}`)

            .then(response => {
                this.setState({
                    data: response.data[0]
                })

            })


        //const data = this.state.data;

        //console.log("Longitude : " + data.lon)
        //console.log("Latitude : " + data.lat)

        //let latitude = this.props.lat
        //let longitude = this.props.lon

        //console.log(this.state)

        //console.log("Latitude = " + latitude)
        //console.log("Longitude = " + longitude)

    }
    render() {

        //const data = this.state.data;

        //console.log("Longitude : " + data.lon)
        //console.log("Latitude : " + data.lat)

        /*
        const locationCity = data.map(location => {
            return <p>{location.lat} - {location.lon}</p>
          })*/
        return (
            <div>
                {/*locationCity*/}
            </div>
        )
    }

}
