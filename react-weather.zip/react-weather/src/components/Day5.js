import React, { Component } from 'react'
import axios from 'axios';

export default class Day5 extends Component {
    state = {
        data: {}
    }

    componentDidMount() {


        let latitude = 50.4291723;
        let longitude = 2.8319805;
        
        let WEATHER_API = `https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&units=metric&lang=fr&exclude=minutely,hourly,alerts&appid=37bddde895b74620b111148941cfe613`;

        axios.get(`${WEATHER_API}`)

            .then(res => {
                this.setState({
                    data: res.data
                })
            })

        //console.log(this.state)

        console.log(this.state);
    }
    render() {

        const data = this.state.data;

        //const location = this.state.location;

        //console.log(location)
        if (Object.keys(data).length !== 0) {

            const icon_nextday4 = this.state.data.daily[4].weather[0].icon;
            const img_nextday4 = `http://openweathermap.org/img/wn/${icon_nextday4}@2x.png`

            const today = data.daily[4];
            const todayWeekDay = new Date(today.dt * 1000).toLocaleString("fr-FR", { weekday: "long" });

            // Checker que data est vide
            // S'il est pas vide, alors this.state.data.current... a une valeur
            return (
                <div className="box_nextday next_day">
                    <div className="content">
                        <p className="day_name">{todayWeekDay}</p>
                        <img src={img_nextday4} alt="" />
                        <p className="day_infos">{this.state.data.daily[4].temp.max}°C</p>
                    </div>
                </div>
            );
        } else {
            // Sinon j'affiche un loading
            return (
                <p>Loading...</p>
            );
        }
    }
}